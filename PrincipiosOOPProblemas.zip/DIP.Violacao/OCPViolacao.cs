﻿
namespace Violacoes
{
    public class AutenticacaoService : Base.BaseService
    {
        IUsuario usuario;
        IRecurso recurso;
        IAplicacao aplicacao;
        IPerfilRecurso perfilRecurso;
        UsuarioService uService;
        IUnidadeAdministrativa unidadeAdminsitrativa;
        IPessoaFisica pessoaService;


        public AutenticacaoService(ILogError l, IUsuario u, IRecurso r, IAplicacao a, IPerfilRecurso pr, IPerfilUsuario pu, IPessoaFisica pe, IUnidadeAdministrativa ua)
            : base(l)
        {
            usuario = u;
            recurso = r;
            aplicacao = a;
            perfilRecurso = pr;
            unidadeAdminsitrativa = ua;
            uService = new UsuarioService(l, u, pu, pe, ua);
            pessoaService = pe;
        }

        public bool EstaAutenticado()
        {
            return HttpContext.Current.Request.Cookies.AllKeys.Contains(_aut)
                && HttpContext.Current.Request.Cookies[_aut].Values.Count > 0
                && HttpContext.Current.Request.Cookies[_aut].Values[_userKey] != string.Empty;
        }

        public bool Autenticar(ref Model.Entity.Seguranca.Usuario objModel)
        {
            if (String.IsNullOrEmpty(objModel.ChaveDeAcesso) || String.IsNullOrEmpty(objModel.Senha))
                throw new Exception("Preencha os campos com seu usuário e senha");

            try
            {
                DefinirPropriedadesDeConsulta(ref objModel);
                DefinirConfiguracoesPadrao(ref objModel);
// VIOLACAO OCP SE INCLUIR MAIS UM TIPO DE AUTENTICACAO VOU TER QUE MEXER NESSE CASE PARA INCLUIR MAIS NOVAS FORMAS PROBLEMA PARA TESTAR.  
                IAutenticacao autenticacao = null;
                switch (objModel.TipoAutenticacao)
                {
                    case TipoAutenticacao.Ad:
                        {
                            autenticacao = new Ad(usuario, unidadeAdminsitrativa, pessoaService);
                            break;
                        }
                    case TipoAutenticacao.SSO:
                        {
                            autenticacao = new SSO(usuario, unidadeAdminsitrativa);
                            break;
                        }
                    case TipoAutenticacao.Facebook:
                        {
                            autenticacao = new Facebook();
                            break;
                        }
                    case TipoAutenticacao.Twitter:
                        {
                            autenticacao = new Twitter();
                            break;
                        }
                }

                ResultadoOperacaoVO<ResultadoAutenticacao> retorno = autenticacao.Autenticar(ref objModel);
                bool autenticou = retorno.Sucesso;

                if (retorno.Resultado != null)
                {
                    if (retorno.Resultado.CriarNovoUsuario)
                    {
                        // Se o processo identificou o usuario no AD mas, 
                        // o usuário ainda não existe no banco tentar criar um novo com o perfil padrão
                        List<PerfilUsuario> perfis = new List<PerfilUsuario>() { new PerfilUsuario { Perfil = Convert.ToInt32(ConfigurationManager.AppSettings["IdPerfilPadrao"]), Status = true } };
                        AcaoEfetuada retornoCriacao = uService.Salvar(objModel, perfis);
                        autenticou = retornoCriacao == AcaoEfetuada.InseridoSucesso ? true : false;
                    }
                }

                if (!autenticou)
                {
                    AdicionarTentativaInvalidaUsuario(ref objModel);
                }

                // Se não for inserir um novo usuário AD
                // Valida as tentativas de Login

                if (objModel.TipoUsuario == TipoUsuario.SSO)
                {
                    ValidarTentativasDeLogin(ref objModel, autenticou);
                }
                if (!string.IsNullOrEmpty(retorno.Mensagem))
                {
                    //Exibe a mensagem de erro captada no retorno da operação
                    throw new Exception(retorno.Mensagem);
                }

                uService.AtualizarUltimaDataAcesso(ref objModel);
                AutenticarUsuario(objModel);

                return autenticou;
            }
            catch (Exception ex)
            {
                throw base.ErrorLog(ex);
            }
        }

        private void DefinirPropriedadesDeConsulta(ref Usuario objModel)
        {
            //Definições padrão de pesquisa no banco de dados para o objeto usuário
            objModel.Status = true;
        }

        private void DefinirConfiguracoesPadrao(ref Usuario objModel)
        {
            #region Empresa Padrão

            int idEmpresaPadrao = 0;
            if (!int.TryParse(ConfigurationManager.AppSettings["IdEmpresaPadrao"].ToString(), out idEmpresaPadrao))
                throw new Exception(@"A propriedade IdEmpresaPadrao não foi localizada nas configurações do sistema."); //Rever esta mensagem

            objModel.TipoEmpresa = (TipoEmpresa)idEmpresaPadrao;

            #endregion

            #region Codigo UA

            int idUnidadeAdministrativa = 0;
            if (!int.TryParse(ConfigurationManager.AppSettings["IdUAGenerica"].ToString(), out idUnidadeAdministrativa))
                throw new Exception(@"A propriedade IdUAGenerica não foi localizada nas configurações do sistema."); //Rever esta mensagem

            objModel.CodigoUA = idUnidadeAdministrativa;

            #endregion
        }

        private void ValidarTentativasDeLogin(ref Usuario objModel, bool autenticou)
        {
            if (objModel.Bloqueado)
                throw new Exception("Usuário bloqueado. Favor solicitar ao responsável! ");

            int tentativasBloqueioLogin;
            if (!int.TryParse(ConfigurationManager.AppSettings["TentativasBloqueioLogin"], out tentativasBloqueioLogin))
                throw new Exception("A propriedade 'TentativasBloqueioLogin' não foi localizada nas configurações do sistema."); //Rever esta mensagem

            int tentativasRestantes = tentativasBloqueioLogin - objModel.TentativasLoginInvalidas;

            if (tentativasRestantes <= 0)
            {
                if (BloquearUsuario(ref objModel)) { }

                throw new Exception("Limite de tentativas excedidas. Favor solicitar ao responsável! ");
            }
            else if (!autenticou)
            {
                objModel.TentativasLoginInvalidas++;
                objModel.DataAlteracao = DateTime.Now;
                throw new Exception("Usuário ou a Senha incorreto. Tentativas restantes: " + tentativasRestantes);
            }
        }

        private bool BloquearUsuario(ref Usuario objModel)
        {
            Usuario usuarioBloqueado = null;
            if (objModel.TipoAutenticacao == TipoAutenticacao.Ad)
                usuarioBloqueado = uService.Search(new Usuario() { ChaveDeAcesso = objModel.ChaveDeAcesso, CPF = objModel.CPF, Status = true }).FirstOrDefault();
            else
            {
                //Não deve ser informado a senha para obter o Usuario corretamente pela chave de acesso
                usuarioBloqueado = uService.Search(new Usuario { ChaveDeAcesso = objModel.ChaveDeAcesso, Status = true }).FirstOrDefault();
            }

            usuarioBloqueado.UsuarioAlteracao = usuarioBloqueado.Codigo;
            usuarioBloqueado.Bloqueado = true;
            usuarioBloqueado.DataAlteracao = DateTime.Now;
            uService.Salvar(usuarioBloqueado, null);
            return true;
        }

        private void AdicionarTentativaInvalidaUsuario(ref Usuario objModel)
        {
            Usuario usuario = null;
            if (objModel.TipoAutenticacao == TipoAutenticacao.Ad)
                usuario = uService.Search(new Usuario() { ChaveDeAcesso = objModel.ChaveDeAcesso, CPF = objModel.CPF, Status = true }).FirstOrDefault();
            else
            {
                //Não deve ser informado a senha para obter o Usuario corretamente pela chave de acesso
                usuario = uService.Search(new Usuario { ChaveDeAcesso = objModel.ChaveDeAcesso, Status = true }).FirstOrDefault();
            }

            usuario.UsuarioAlteracao = usuario.Codigo;
            usuario.DataAlteracao = DateTime.Now;

            usuario.TentativasLoginInvalidas++;

            uService.Salvar(usuario, null);

            objModel = usuario;
        }

        private void AutenticarUsuario(Usuario objModel)
        {
            HttpCookie cookie = new HttpCookie(_aut);
            cookie.Values.Add(_userId, StringExtension.Encrypt(objModel.Codigo.ToString()));
            cookie.Values.Add(_userKey, StringExtension.Encrypt(objModel.ChaveDeAcesso));
            cookie.Values.Add(_userName, string.IsNullOrEmpty(objModel.Nome) ? StringExtension.Encrypt(objModel.ChaveDeAcesso) : StringExtension.Encrypt(objModel.Nome));
            cookie.Values.Add(_TipoAutenticacao, StringExtension.Encrypt(Convert.ToString(objModel.TipoAutenticacao)));
            cookie.Expires = DateTime.Now.AddHours(4);
            HttpContext.Current.Response.Cookies.Add(cookie);
        }


        public bool AutenticarToken(string token)
        {
            try
            {
                //autenticacao = new SSO(usuario);
                //var usuarioRetorno = autenticacao.AutenticarToken(token);

                //if (usuarioRetorno == null)
                //    throw new Exception("Token Inválido");

                //if (!uService.ValidarLoginAcesso(ref usuarioRetorno, autenticacao))
                //{
                //    throw new Exception("Usuário ou senha inválido.");
                //}
            }
            catch (Exception ex)
            {
                throw base.ErrorLog(ex);
            }

            return true;
        }

        public void EncerrarSessao()
        {
            if (EstaAutenticado())
            {
                HttpContext.Current.Request.Cookies.Remove(_aut);
                HttpCookie myCookie = new HttpCookie(_aut);
                myCookie.Expires = DateTime.Now.AddDays(-1d);
                HttpContext.Current.Response.Cookies.Add(myCookie);

                base.RefreshUsuarioLogado();
            }
        }

        public Usuario GetUsuarioLogado()
        {
            Usuario usu = null;

            if (EstaAutenticado())
            {
                try
                {
                    HttpCookie cookie = HttpContext.Current.Request.Cookies[_aut];

                    usu = uService.Search(new Usuario { ChaveDeAcesso = StringExtension.Decrypt(cookie.Values[_userKey]), Status = true }).FirstOrDefault();
                    usu.TipoAutenticacao = (TipoAutenticacao)Enum.Parse(typeof(TipoAutenticacao), StringExtension.Decrypt(cookie.Values[_TipoAutenticacao]));
                }
                catch
                {
                    EncerrarSessao();
                }
            }

            return usu;
        }

        public bool PermiteAcesso(Usuario usuario, string url, string operacao)
        {
            if (usuario.SenhaExpirada == true)
            {
                return false;
            }

            if (String.IsNullOrEmpty(url))
            {
                return true;
            }

            //Recupera recurso acessado
            Recurso _recurso = recurso.Search(new Recurso { URL = url, Status = true }).FirstOrDefault();

            // Recupera o relacionamento Usuário Logado x Recurso sendo acessado
            if (_recurso != null)
            {
                //Recupera a aplicação em execução
                Aplicacao apl = aplicacao.Search(new Aplicacao { Codigo = _recurso.Aplicacao }).FirstOrDefault();

                //Se a aplicação está inativa, bloqueia o acesso
                if (apl == null || apl.Status == false)
                {
                    return false;
                }

                //Se o recurso for publico, libera o acesso
                if (_recurso.Publico.Equals(true))
                {
                    return true;
                }

                //Retorna se os perfis do Usuário permite acesso ao recurso
                return GetPermissaoPerfilUsuario(_recurso, usuario, operacao);
            }
            else // Caso o recurso solicitado não seja encontrado, redireciona o usuário para a página de Acesso Negado
            {
                return false;
            }
        }


        /// <summary>
        /// Retorna se possui acesso a operação do recurso
        /// </summary>
        /// <param name="recurso">Recurso Model acessado</param>
        /// <param name="perfis">Lista de perfis para consulta de acesso</param>
        /// <returns>Retorna verdadeiro quando o Usuário possui acesso</returns>
        private bool GetPermissaoPerfilUsuario(Recurso r, Usuario u, string operacao)
        {
            List<PerfilRecurso> list = perfilRecurso.GetPerfilRecursoByUsuario(u, r.Codigo).ToList();

            if (list.Count == 0)
            {
                //Caso não tenha redireciona para acesso negado
                return false;
            }
            else
            {
                foreach (var item in list)
                {
                    switch (operacao)
                    {
                        case "Incluir":
                            if (item.Incluir)
                            { return true; }
                            break;
                        case "Alterar":
                            if (item.Alterar)
                            { return true; }
                            break;
                        case "Excluir":
                            if (item.Excluir)
                            { return true; }
                            break;
                        case "Consultar":
                        default:
                            if (item.Consultar)
                            { return true; }
                            break;
                    }

                }

                return false;
            }
        }
    }
}
