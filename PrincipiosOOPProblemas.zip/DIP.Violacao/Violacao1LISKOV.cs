﻿
namespace Violacoes
{
    // VIOLACAO Conceito PessoaFisica herda de Endereco 
    // VIOLACAO Conceito Empresa herda de Endereco
    // nao tem relação de familia e deveria fazer mais sentido composição
    public class Endereco : Base.BaseModel
    {

        /// <summary>
        /// Logradouro.
        /// </summary>
        [Column("ds_logradouro")]
        [Required(ErrorMessage = "O campo Logradouro é de preenchimento obrigatório")]
        public string Logradouro { get; set; }

        /// <summary>
        /// Número.
        /// </summary>
        [Display(Name = "Número"), Required(ErrorMessage = "O campo número é obrigatório")]
        [Column("ds_numero")]
        public string Numero { get; set; }

        /// <summary>
        /// Complemento.
        /// </summary>
        [Column("ds_complemento")]
        public string Complemento { get; set; }

        /// <summary>
        /// Bairro.
        /// </summary>
        [Required(ErrorMessage = "O campo Bairro é obrigatório")]
        [Column("ds_bairro")]
        public string Bairro { get; set; }

        /// <summary>
        /// Município.
        /// </summary>
        [Display(Name = "Município"), Required(ErrorMessage = "O campo Município é obrigatório")]
        [Column("ds_municipio")]
        public string Municipio { get; set; }

        /// <summary>
        /// CEP.
        /// </summary>
        [Required(ErrorMessage = "O campo CEP é obrigatório")]
        [Column("ds_cep")]
        [RegularExpression(@"\d{2}\.?\d{3}\-?\d{3}", ErrorMessage = "CEP informado é inválido. Favor verificar!")]
        public string CEP { get; set; }

        /// <summary>
        /// UF.
        /// </summary>
        //  Se usar o Range a mensagem não valida corretamente
        //  [Range(1, 27, ErrorMessage="O campo UF é obrigatório")] 
        [Required(ErrorMessage = "O campo UF é obrigatório")]
        [Column("ds_uf")]
        public UF UF { get; set; }

    }

    public class PessoaFisica : Endereco
    {

        #region Métodos públicos

        #endregion

        #region Propriedades Públicas

        [Display(Name = "Código")]
        [Column("id_pessoa_fisica")]
        public virtual int Codigo { get; set; }

        /// <summary>
        /// Tipo da Pessoa
        /// </summary>
        [Display(Name = "Tipo Pessoa")]
        [Required(ErrorMessage = "Informe tipo da pessoa")]
        [Column("id_tipo_pessoa")]
        public TipoPessoa? TipoPessoa { get; set; }

        /// <summary>
        /// Descrição Tipo da Pessoa
        /// </summary>
        [Display(Name = "Descrição Tipo Pessoa")]
        [Column("ds_tipo_pessoa")]
        public string DescTipoPessoa { get; set; }

        /// <summary>
        /// Nome da Pessoa.
        /// </summary>
        [Display(Name = "Nome")]
        [Required(ErrorMessage = "O campo Nome é obrigatório", AllowEmptyStrings = false)]
        [Column("no_pessoa")]
        public string Nome { get; set; }

        /// <summary>
        /// CPF da Pessoa.
        /// </summary>
        [Display(Name = "CPF")]
        [Required(ErrorMessage = "O campo CPF é obrigatório", AllowEmptyStrings = false)]
        [Column("ds_cpf")]
        public string CPF { get; set; }

        /// <summary>
        /// Data Nascimento da Pessoa.
        /// </summary>
        [Display(Name = "Data Nascimento")]
        [Required(ErrorMessage = "O campo Data Nascimento é obrigatório", AllowEmptyStrings = false)]
        [DataType(DataType.Date)]
        [Column("dt_nascimento")]
        public DateTime? DataNascimento { get; set; }

        /// <summary>
        /// Sexo da Pessoa.
        /// </summary>
        [Display(Name = "Sexo")]
        [Required(ErrorMessage = "O campo Sexo é obrigatório", AllowEmptyStrings = false)]
        [Column("ds_sexo")]
        public string Sexo { get; set; }

        /// <summary>
        /// Email da Pessoa.
        /// </summary>
        [Display(Name = "Email")]
        [Required(ErrorMessage = "O campo E-mail é obrigatório", AllowEmptyStrings = false)]
        [Column("ds_email")]
        public string Email { get; set; }

        /// <summary>
        /// Telefone.
        /// </summary>
        [Display(Name = "Telefone")]
        [Column("ds_telefone")]
        public string Telefone { get; set; }

        /// <summary>
        /// Celular.
        /// </summary>
        [Display(Name = "Celular")]
        [Column("ds_celular")]
        public string Celular { get; set; }

        #endregion
    }


    public class Empresa : Endereco
    {
        #region Construtores

        /// <summary>
        /// Construtor padrão. Padrão.
        /// </summary>
        public Empresa() { }


        /// <summary>
        /// Construtor padrão. Personalizado.
        /// </summary>
        /// <param name="_codigo"> Código da Empresa.</param>
        /// <param name="_cnpj"> CNPJ da Empresa.</param>
        /// <param name="_razaoSocial"> Razão Social.</param>
        /// <param name="_nomeFantasia"> Nome Fantasia.</param>
        /// <param name="_logradouro"> Logradouro.</param>
        /// <param name="_numero"> Número.</param>
        /// <param name="_complemento"> Complemento.</param>
        /// <param name="_bairro"> Bairro.</param>
        /// <param name="_municipio"> Município.</param>
        /// <param name="_cep"> CEP.</param>
        /// <param name="_uf"> UF.</param>
        public Empresa(
            int _codigo,
            string _cnpj,
            TipoEmpresa _tipoEmpresa,
            string _razaoSocial,
            string _nomeFantasia,
            string _logradouro,
            string _numero,
            string _complemento,
            string _bairro,
            string _municipio,
            string _cep,
            UF _uf)
        {
            this.Codigo = _codigo;
            this.CNPJ = _cnpj;
            this.TipoEmpresa = _tipoEmpresa;
            this.RazaoSocial = _razaoSocial;
            this.NomeFantasia = _nomeFantasia;
            this.Logradouro = _logradouro;
            this.Numero = _numero;
            this.Complemento = _complemento;
            this.Bairro = _bairro;
            this.Municipio = _municipio;
            this.CEP = _cep;
            //this.UF = _uf;
        }

        #endregion

        #region Propriedades Públicas

        [Column("id_empresa")]
        [Display(Name = "Código")]
        public int Codigo { get; set; }

        [Column("id_endereco")]
        [Display(Name = "Endereço")]
        public int Endereco { get; set; }

        /// <summary>
        /// CNPJ da Empresa.
        /// </summary>
        [Column("ds_cnpj")]
        [Display(Name = "CNPJ")]
        [Required(ErrorMessage = "O campo CNPJ é de preenchimento obrigatório")]
        [CNPJAttribute]
        public string CNPJ { get; set; }

        /// <summary>
        /// Tipo da Empresa.
        /// </summary>
        [Display(Name = "Tipo Empresa")]
        [Column("id_tipo_empresa")]
        [Required(ErrorMessage = "O campo Tipo Empresa é de preenchimento obrigatório")]
        public TipoEmpresa TipoEmpresa { get; set; }

        /// <summary>
        /// Razão Social.
        /// </summary>
        [Display(Name = "Razão Social")]
        [Column("ds_razao_social")]
        [Required(ErrorMessage = "O campo Razão Social é de preenchimento obrigatório")]
        public string RazaoSocial { get; set; }

        /// <summary>
        /// Nome Fantasia.
        /// </summary>
        [Display(Name = "Nome Fantasia")]
        [Column("ds_nome_fantasia")]
        [Required(ErrorMessage = "O campo Nome Fantasia é de preenchimento obrigatório")]
        public string NomeFantasia { get; set; }

        #endregion
    }
    
}
