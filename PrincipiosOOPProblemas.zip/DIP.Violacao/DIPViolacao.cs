﻿

namespace Violacoes
{
    public class DIPViolacao
    {
        internal readonly ILogError LogErros;
        internal readonly ILogError LogErrosXML;

// VIOLACAO Assim como o ILogError essa informação deveria recber por injeção
        internal readonly EmailHelper Email = new EmailHelper();

        #region Atributos
        protected const string _aut = "aut";
        protected string _userId
        {
            get { return StringExtension.Encrypt("UsuCodigoIdentificador"); }
        }
        protected string _userKey
        {
            get { return StringExtension.Encrypt("UsuChaveDeAcesso"); }
        }
        protected string _userName
        {
            get { return StringExtension.Encrypt("UsuNomeDeUsuario"); }
        }
        protected string _TipoAutenticacao
        {
            get { return StringExtension.Encrypt("TipoAutenticacao"); }
        }

        #endregion

        // VIOLACAO   Classe Concreta - A camada acima deveria obter a informação e passar valor da configuração 
        // System.Configuration.ConfigurationManager.AppSettings
        internal string Log
        {
            get
            {
                return System.Configuration.ConfigurationManager.AppSettings["log"];
            }
        }
        public BaseService(ILogError l, ILogError logXML = null)
        {
            this.LogErros = l;
            if (logXML == null)
                this.LogErrosXML = new LogErrorXml();
            else
                this.LogErrosXML = logXML;
        }
        protected void PreInsertModel(BaseModel model)
        {
            if (model.DataCriacao == DateTime.MinValue || model.UsuarioCriacao == 0)
            {
                model.DataCriacao = DateTime.Now;
                model.UsuarioCriacao = GetUserIdLogado();
            }
        }
        protected void PreUpdateModel(BaseModel model)
        {
            model.DataAlteracao = DateTime.Now;
            model.UsuarioAlteracao = GetUserIdLogado();
        }
        private static readonly Dictionary<Type, int> TypeErros = new Dictionary<Type, int>
        {
            {typeof (System.Net.WebException), 0},
            {typeof (System.Xml.XmlException), 1},
            {typeof (InvalidCastException), 2},
            {typeof (Exception), 3}
        };
        protected AcaoEfetuada LogStatus(string logTable, int id)
        {
            SaveLog(logTable, id.ToString(), TipoLog.StatusAlterado);
            return AcaoEfetuada.StatusAlterado;
        }
        protected AcaoEfetuada LogUpdate(string logTable, int id)
        {
            SaveLog(logTable, id.ToString(), TipoLog.Update);
            return AcaoEfetuada.AlteradoSucesso;
        }

        protected AcaoEfetuada LogInsert(string logTable, int id)
        {
            SaveLog(logTable, id.ToString(), TipoLog.Insert);
            return AcaoEfetuada.InseridoSucesso;
        }
        protected AcaoEfetuada LogDelete(string logTable, int id)
        {
            SaveLog(logTable, id.ToString(), TipoLog.Delete);
            return AcaoEfetuada.ExcluidoSucesso;
        }
        protected void SaveLog(string tabela, string id_registro, TipoLog tipo)
        {
            try
            {
                LogErros.SaveError(GetLogAplicacao(tabela, id_registro, tipo));
            }
            catch (Exception ex)
            {
                ErrorLog(ex);
            }
        }
        protected Exception ErrorLog(Exception ex)
        {
            if (this.Log == "BD")
                LogErros.SaveError(GetLogAplicacao(ex, TipoLog.Erro));
            else if (this.Log == "Arquivo")
                LogErrosXML.SaveError(GetLogAplicacao(ex, TipoLog.Erro));


            if (!TypeErros.ContainsKey(ex.GetType()))
                return new Exception("Erro ao processar sua solicitação. Por favor entre em contato com o Administrador do Sistema.", ex);
            switch (TypeErros[ex.GetType()])
            {
                case 0:
                    return new Exception("XXXX", ex);
                case 1:
                    return new Exception("XXX", ex);
                case 2:
                    return new Exception("XXX2", ex);
                case 3:
                    return new Exception(ex.Message, ex);
                default:
                    return new Exception("XX2", ex);
            }
        }

        public static string RandomPassword(int passwordLength)
        {
            const string chars = "abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ0123456789#@$";
            var sb = new StringBuilder();
            var rd = new Random();
            for (var i = 0; i < passwordLength; i++)
            { sb.Append(chars[rd.Next(0, chars.Length)]); }
            return sb.ToString();
        }

        public static string GetSHA256Hash(string input)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] data = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

                StringBuilder sBuilder = new StringBuilder();

                for (int i = 0; i < data.Length; i++)
                {
                    sBuilder.Append(data[i].ToString("x2"));
                }

                return sBuilder.ToString().ToUpper();
            }
        }

        private LogAplicacao GetLogAplicacao(Exception ex, TipoLog tipo)
        {
// VIOLACAO CRIANDO O OBJETO DE LOG DE APLICACAO CLASSE CONCRETA 
            LogAplicacao log = new LogAplicacao();

            log.DATA = DateTime.Now;
            log.APLICACAO = "Fiscalização";
            log.TIPO_LOG = tipo;
            log.ID_USUARIO = GetUserIdLogado();
            log.MENSAGEM = ex.Message;
            log.STACKTRACE = ex.StackTrace;
            log.RECURSO = GetNomePagina();
            log.EXCEPTION = ex.ToString();
            log.Ex = ex;

            return log;
        }

        private LogAplicacao GetLogAplicacao(string tabela, string id_registro, TipoLog tipo)
        {
 // VIOLACAO CRIANDO O OBJETO DE LOG DE APLICACAO CLASSE CONCRETA
            LogAplicacao log = new LogAplicacao();

            log.DATA = DateTime.Now;
            log.APLICACAO = "Fiscalização";
            log.TIPO_LOG = tipo;
            log.TABELA = tabela;
            log.REGISTRO = id_registro;
            log.ID_USUARIO = GetUserIdLogado();
            log.RECURSO = GetNomePagina();
            log.MENSAGEM = String.Format("{0} do registro {1} na tabela {2}", tipo, id_registro, tabela);

            return log;
        }

        protected void RefreshUsuarioLogado()
        {
             HttpContext.Current.Session["UsuarioLogado"] = null;
        }

        protected string[] CriaNumeroProtocolo(string numeroProtocolo)
        {
            return numeroProtocolo.Split('/');
        }

        #region Log

        public List<LogAplicacao> Search(LogFilter filtro)
        {
            return LogErros.Search(filtro).ToList();
        }

        public List<string> SearchXML(string arquivo)
        {
            return LogErrosXML.Search(arquivo).ToList();
        }

        public string GetXML(string arquivo)
        {
            return LogErrosXML.GetXML(arquivo);
        }


        #endregion

        #region Cookies
        public string GetNomeUsuarioLogado()
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[_aut];
            return StringExtension.Decrypt(cookie.Values[_userName]);
        }
        public string GetUserKeyLogado()
        {
            HttpCookie cookie = HttpContext.Current.Request.Cookies[_aut];
            return StringExtension.Decrypt(cookie.Values[_userKey]);
        }
        public int GetUserIdLogado()
        {
            return br.procon.Fiscalizacao.Core.Helper.AutenticacaoHelper.GetUserIdLogado();
        }
        public string GetNomePagina()
        {
            try
            {
                return HttpContext.Current.Request.Url.AbsolutePath;
            }
            catch
            {
                return string.Empty;
            }
        }
        #endregion

        #region Email

        public void EnviarEmail(string assunto, string[] destinatarios, string mensagem)
        {
            Email.Enviar(assunto, destinatarios, mensagem, System.Net.Mail.MailPriority.Normal);
        }

        #endregion
    }

    public class BaseService<T, TLista> : BaseService where T : BaseModel
    {
        protected IDal<T, TLista> repositorio;

        public BaseService(ILogError l, ILogError logXML = null) : base(l, logXML)
        {
        }


        public virtual ResultadoOperacaoVO<TLista> ObterPorId(int id)
        {
            ResultadoOperacaoVO<TLista> resultado = new ResultadoOperacaoVO<TLista>();

            try
            {
                resultado.Resultado = repositorio.ObterPorId(id);

                resultado.Sucesso = true;
            }
            catch (Exception ex)
            {
                throw base.ErrorLog(ex);
            }

            return resultado;
        }

        public virtual ResultadoOperacaoVO<IEnumerable<TLista>> Buscar(FiltroBase filtro)
        {
            var resultado = new ResultadoOperacaoVO<IEnumerable<TLista>>();

            try
            {
                resultado.Resultado = repositorio.Buscar(filtro);
                resultado.Sucesso = true;
            }
            catch (Exception ex)
            {
                throw base.ErrorLog(ex);
            }

            return resultado;
        }

        public virtual ResultadoOperacaoVO Excluir(int id)
        {
            ResultadoOperacaoVO resultado = new ResultadoOperacaoVO();

            try
            {
                var resultadoOperacao = repositorio.Excluir(id);

                resultado.Sucesso = resultadoOperacao > 0;
                resultado.Mensagem = MensagensGerais.SucessoOperacao;
            }
            catch (Exception ex)
            {
                throw base.ErrorLog(ex);
            }

            return resultado;
        }

        public virtual ResultadoOperacaoVO AlterarStatus(int id, bool ativo)
        {
            ResultadoOperacaoVO<bool> resultado = new ResultadoOperacaoVO<bool>();
            try
            {
                resultado.Sucesso = repositorio.AlterarStatus(ativo ? Status.Ativo : Status.Inativo, id);
                resultado.Mensagem = MensagensGerais.SucessoOperacao;
            }
            catch (Exception ex)
            {
                throw base.ErrorLog(ex);
            }

            return resultado;
        }
    }

    public class BaseService<T, TLista, TFiltro> : BaseService where T : BaseModel
    {
        protected IDal<T, TLista, TFiltro> repositorio;

        public BaseService(ILogError l, ILogError logXML = null)
            : base(l, logXML)
        {
        }


        public virtual ResultadoOperacaoVO<TLista> ObterPorId(int id)
        {
            ResultadoOperacaoVO<TLista> resultado = new ResultadoOperacaoVO<TLista>();

            try
            {
                resultado.Resultado = repositorio.ObterPorId(id);

                resultado.Sucesso = true;
            }
            catch (Exception ex)
            {
                throw base.ErrorLog(ex);
            }

            return resultado;
        }

        public virtual ResultadoOperacaoVO<IEnumerable<TLista>> Buscar(TFiltro filtro)
        {
            var resultado = new ResultadoOperacaoVO<IEnumerable<TLista>>();

            try
            {
                resultado.Resultado = repositorio.Buscar(filtro);
                resultado.Sucesso = true;
            }
            catch (Exception ex)
            {
                throw base.ErrorLog(ex);
            }

            return resultado;
        }

        public virtual ResultadoOperacaoVO Excluir(int id)
        {
            ResultadoOperacaoVO resultado = new ResultadoOperacaoVO();

            try
            {
                var resultadoOperacao = repositorio.Excluir(id);

                resultado.Sucesso = resultadoOperacao > 0;
                resultado.Mensagem = MensagensGerais.SucessoOperacao;
            }
            catch (Exception ex)
            {
                throw base.ErrorLog(ex);
            }

            return resultado;
        }

        public virtual ResultadoOperacaoVO AlterarStatus(int id, bool ativo)
        {
            ResultadoOperacaoVO<bool> resultado = new ResultadoOperacaoVO<bool>();
            try
            {
                resultado.Sucesso = repositorio.AlterarStatus(ativo ? Status.Ativo : Status.Inativo, id);
                resultado.Mensagem = MensagensGerais.SucessoOperacao;
            }
            catch (Exception ex)
            {
                throw base.ErrorLog(ex);
            }

            return resultado;
        }
    }

    public enum AcaoEfetuada
    {
        InseridoSucesso,
        AlteradoSucesso,
        StatusAlterado,
        ExcluidoSucesso

    }
}
