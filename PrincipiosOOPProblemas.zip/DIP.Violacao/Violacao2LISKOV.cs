﻿
namespace Violacao
{
    // VIOLACAO a ideia e herdar porque todos os objetos precisam fazer ter as informações para log das operações neles efetuadas
    // usuario de criacao, data de criação, usuario alteracao e data de alteracao.
    // Deveria ser melhor usar Composicao nesse caso ?? 
    // VIOLACAO classe Parada 
    // VIOLACAO classe Uusuario 
    public class BaseModel
    {
        #region Construtores

        /// <summary>
        /// Construtor padrão. padrão.
        /// </summary>
        public BaseModel() { }

        /// <summary>
        /// Construtor padrão. personalizado.
        /// </summary>
        /// <param name="_status"> Status do Objeto.</param>
        /// <param name="_dataCriacao"> Data de criação do Registro.</param>
        /// <param name="_usuarioCriacao"> Usuário que criou o registo.</param>
        /// <param name="_programaCriacao"> Programa que criou o registro.</param>
        /// <param name="_dataAlteracao"> Data de atualização do registro.</param>
        /// <param name="_usuarioAlteracao"> Usuário que alterou o registro.</param>
        /// <param name="_programaAlteracao"> Programa que alterou o registro.</param>
        public BaseModel(
            bool _status,
            DateTime _dataCriacao,
            int _usuarioCriacao,
            DateTime _dataAlteracao,
            int _usuarioAlteracao)
        {
            this.Status = _status;
            this.DataCriacao = _dataCriacao;
            this.UsuarioCriacao = _usuarioCriacao;
            this.DataAlteracao = _dataAlteracao;
            this.UsuarioAlteracao = _usuarioAlteracao;
        }

        #endregion

        #region Métodos públicos

        /// <summary>
        /// Sobrecarga do método ToString() da classe Object.
        /// </summary>
        /// <returns> String com as propriedades do objeto.</returns>
        public override string ToString()
        {
            string sResult = string.Empty;

            PropertyInfo[] propertyInfo = this.GetType().GetProperties();

            sResult += string.Format("Class={0}|", this.GetType().Name);

            foreach (PropertyInfo pInfo in propertyInfo)
            {
                sResult += string.Format("{0}={1}|", pInfo.Name, pInfo.GetValue(this, null));
            }

            return sResult;
        }

        #endregion

        #region Propriedades Públicas

        /// <summary>
        /// Ativo ou Inativo
        /// </summary>
        [Display(Name = "Status")]
        [Column("bl_ativo")]
        public bool? Status { get; set; }

        /// <summary>
        /// Data de criação do registro.
        /// </summary>
        [Display(Name = "Data Criação"), DataType(DataType.DateTime)]
        [Column("dt_criacao")]
        public virtual DateTime DataCriacao { get; set; }

        /// <summary>
        /// Usuário que criou o registro.
        /// </summary>
        [Display(Name = "Usuário Criação")]
        [Column("id_usuario_criacao")]
        public int UsuarioCriacao { get; set; }

        /// <summary>
        /// Data da última alteração do registro.
        /// </summary>
        [Display(Name = "Data Alteração")]
        [Column("dt_alteracao")]
        public DateTime DataAlteracao { get; set; }

        /// <summary>
        /// Usuário responsável pela última alteração do registro.
        /// </summary>
        [Display(Name = "Usuário Alteração")]
        [Column("id_usuario_alteracao")]
        public int UsuarioAlteracao { get; set; }

        #endregion
    }

    public class Parada : Base.BaseModel
    {
        #region Construtores

        /// <summary>
        /// Construtor Padrão.
        /// </summary>
        /// 
        public Parada()
        {
            Modulos = new List<Aplicacao>();
            Recursos = new List<Recurso>();
            Dias = new List<DiaDaSemana>();
        }

        #endregion

        #region Propriedades Públicas

        /// <summary>
        /// Código da Aplicação (PK).
        /// </summary>
        [Display(Name = "Código"), Key]
        [Column("id_agendamento_parada")]
        public int Codigo { get; set; }

        [Display(Name = "Tipo de Parada")]
        [Column("id_tipo_parada")]
        [Required(ErrorMessage = "O campo Tipo de Parada é de preenchimento obrigatório.")]
        public int TipoParada { get; set; }

        [StringLength(100)]
        [Column("ds_motivo")]
        [Required(ErrorMessage = "O campo Motivo é de preenchimento obrigatório.")]
        public string Motivo { get; set; }

        [Required(ErrorMessage = "O campo Ocorrência é de preenchimento obrigatório.")]
        [Column("id_ocorrencia")]
        [Display(Name = "Ocorrência")]
        public int Ocorrencia { get; set; }

        [Column("dt_inicio")]
        public DateTime? DataInicio { get; set; }

        [Column("dt_fim")]
        [DataType(DataType.Date)]
        public DateTime? DataFim { get; set; }

        [Column("hr_inicio")]
        public TimeSpan? HoraInicio { get; set; }

        [Column("hr_fim")]
        public TimeSpan? HoraFim { get; set; }

        [Column("DiasSemanaS")]
        public string DiasSemana { get; set; }

        [Column("DiasS")]
        public string DiasS { get; set; }

        [Column("ModulosS")]
        public string ModulosS { get; set; }
        [Column("RecursosS")]
        public string RecursosS { get; set; }

        public List<DiaDaSemana> Dias { get; set; }

        public IEnumerable<DiaDaSemana> _dias { get; set; }

        [Required(ErrorMessage = "O campo Modulo é de preenchimento obrigatório.")]
        public List<Aplicacao> Modulos { get; set; }

        public List<Recurso> Recursos { get; set; }


        public bool chkDomingo { get; set; }
        public bool chkSegunda { get; set; }
        public bool chkTerca { get; set; }
        public bool chkQuarta { get; set; }
        public bool chkQuinta { get; set; }
        public bool chkSexta { get; set; }
        public bool chkSabado { get; set; }

        public TimeSpan? GetHoraInicioDiaAtual(DiaDaSemana dia)
        {
            switch (dia)
            {
                case DiaDaSemana.Domingo:
                    return HoraInicioDomingo;
                case DiaDaSemana.Segunda:
                    return HoraInicioSegunda;
                case DiaDaSemana.Terça:
                    return HoraInicioTerca;
                case DiaDaSemana.Quarta:
                    return HoraInicioQuarta;
                case DiaDaSemana.Quinta:
                    return HoraInicioQuinta;
                case DiaDaSemana.Sexta:
                    return HoraInicioSexta;
                case DiaDaSemana.Sábado:
                    return HoraInicioSabado;
                default:
                    return null;
            }
        }

        public TimeSpan? GetHoraFimDiaAtual(DiaDaSemana dia)
        {
            switch (dia)
            {
                case DiaDaSemana.Domingo:
                    return HoraFimDomingo;
                case DiaDaSemana.Segunda:
                    return HoraFimSegunda;
                case DiaDaSemana.Terça:
                    return HoraFimTerca;
                case DiaDaSemana.Quarta:
                    return HoraFimQuarta;
                case DiaDaSemana.Quinta:
                    return HoraFimQuinta;
                case DiaDaSemana.Sexta:
                    return HoraFimSexta;
                case DiaDaSemana.Sábado:
                    return HoraFimSabado;
                default:
                    return null;
            }
        }

        public TimeSpan? HoraInicioDomingo { get; set; }
        public TimeSpan? HoraFimDomingo { get; set; }

        public TimeSpan? HoraInicioSegunda { get; set; }
        public TimeSpan? HoraFimSegunda { get; set; }

        public TimeSpan? HoraInicioTerca { get; set; }
        public TimeSpan? HoraFimTerca { get; set; }

        public TimeSpan? HoraInicioQuarta { get; set; }
        public TimeSpan? HoraFimQuarta { get; set; }

        public TimeSpan? HoraInicioQuinta { get; set; }
        public TimeSpan? HoraFimQuinta { get; set; }

        public TimeSpan? HoraInicioSexta { get; set; }
        public TimeSpan? HoraFimSexta { get; set; }

        public TimeSpan? HoraInicioSabado { get; set; }
        public TimeSpan? HoraFimSabado { get; set; }

        public bool chkDomingo24h
        {
            get
            {
                if (HoraInicioDomingo == new TimeSpan(00, 00, 00) && HoraFimDomingo == new TimeSpan(23, 59, 00))
                    return true;
                else
                    return false;
            }
        }
        public bool chkSegunda24h
        {
            get
            {
                if (HoraInicioSegunda == new TimeSpan(00, 00, 00) && HoraFimSegunda == new TimeSpan(23, 59, 00))
                    return true;
                else
                    return false;
            }
        }
        public bool chkTerca24h
        {
            get
            {
                if (HoraInicioTerca == new TimeSpan(00, 00, 00) && HoraFimTerca == new TimeSpan(23, 59, 00))
                    return true;
                else
                    return false;
            }
        }
        public bool chkQuarta24h
        {
            get
            {
                if (HoraInicioQuarta == new TimeSpan(00, 00, 00) && HoraFimQuarta == new TimeSpan(23, 59, 00))
                    return true;
                else
                    return false;
            }
        }
        public bool chkQuinta24h
        {
            get
            {
                if (HoraInicioQuinta == new TimeSpan(00, 00, 00) && HoraFimQuinta == new TimeSpan(23, 59, 00))
                    return true;
                else
                    return false;
            }
        }
        public bool chkSexta24h
        {
            get
            {
                if (HoraInicioSexta == new TimeSpan(00, 00, 00) && HoraFimSexta == new TimeSpan(23, 59, 00))
                    return true;
                else
                    return false;
            }
        }
        public bool chkSabado24h
        {
            get
            {
                if (HoraInicioSabado == new TimeSpan(00, 00, 00) && HoraFimSabado == new TimeSpan(23, 59, 00))
                    return true;
                else
                    return false;
            }
        }

        #endregion
    }

      public class Usuario : PessoaFisica
    {
        #region Construtores

        /// <summary>
        /// Construtor padrão. Padrão.
        /// </summary>
        public Usuario()
        {
            
        }

        #endregion

        #region Propriedades Públicas

        [Column("id_usuario")]
        [Display(Name = "Código")]
        public int Codigo { get; set; }

        [Column("id_pessoa_fisica")]
        [Display(Name = "Código Pessoa Física")]
        public int? CodigoPessoa { get; set; }

        [Column("id_ua")]
        [Display(Name = "Unidade Administrativa")]
        public int? CodigoUA { get; set; }

        /// <summary>
        /// Código da Empresa.
        /// </summary>
        [Column("id_empresa")]
        [Display(Name = "Empresa")]
        [Required(ErrorMessage = "O campo Empresa é obrigatório.")]
        public int Empresa { get; set; }

        /// <summary>
        /// Tipo de Usuário (Enum TipoUsuario).
        /// </summary>     
        [Display(Name = "Tipo de Usuário"), Required(ErrorMessage = "O campo Tipo de Usuário é obrigatório.")]
        [Column("id_tipo_usuario")]
        public TipoUsuario TipoUsuario { get; set; }

        /// <summary>
        /// Tipo de Usuário (Enum TipoUsuario).
        /// </summary>
        [Column("id_tipo_empresa")]
        [Display(Name = "Tipo de Empresa"), Required(ErrorMessage = "O campo Tipo de Empresa é obrigatório.")]
        public TipoEmpresa TipoEmpresa { get; set; }

        [Column("ds_razao_social")]
        public string NomeEmpresa { get; set; }

        /// <summary>
        /// Tipo de Usuário (Enum TipoPessoa).
        /// </summary>
        [Display(Name = "Tipo de Pessoa"), Required(ErrorMessage = "O campo Tipo de Pessoa é obrigatório.")]
        [Column("id_tipo_pessoa")]
        public TipoPessoa TipoPessoa { get; set; }

        /// <summary>
        /// E-mail.
        /// </summary>
        [Required(ErrorMessage = "O campo E-mail é obrigatório.")]
        [DataType(DataType.EmailAddress, ErrorMessage = "Endereço de E-mail inválido.")]
        [Column("ds_email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "O campo Nome é obrigatório.")]
        [Column("ds_nome_usuario")]
        [StringLength(100, ErrorMessage = "O campo Nome é obrigatório.")]
        [Display(Name = "Nome")]
        public string NomeUsuario { get; set; }

        [Column("no_pessoa")]
        public string NomeUsuarioLogado { get; set; }

        /// <summary>
        /// Chave de Acesso ao Portal.
        /// </summary>
        [Display(Name = "Usuário")]
        [Required(ErrorMessage = "O campo Usuário é obrigatório.", AllowEmptyStrings = false)]
        [Column("ds_login")]
        [StringLength(20, ErrorMessage = "O campo Usuário é obrigatório.")]
        public string ChaveDeAcesso { get; set; }

        /// <summary>
        /// Senha (criptografada).
        /// </summary>
        [Required(ErrorMessage = "O campo Senha é obrigatório.", AllowEmptyStrings = false)]
        [DataType(System.ComponentModel.DataAnnotations.DataType.Password)]
        [Column("ds_senha")]
        public string Senha { get; set; }
        
        /// <summary>
        /// Indica se a senha está expirada ou não (Enum SimNao).
        /// </summary>
        [Display(Name = "Senha Expirou?")]
        [Column("bl_senha_expirada")]
        public bool SenhaExpirada { get; set; }

        /// <summary>
        /// Data e hora de expiração da senha.
        /// </summary>
        [Display(Name = "Senha expira"), DataType(DataType.Date)]
        [Column("dt_expiracao_senha")]
        public DateTime DataExpiracaoSenha { get; set; }

        /// <summary>
        /// Data e hora do último acesso.
        /// </summary>
        [Display(Name = "Último Acesso"), DataType(DataType.Date)]
        [Column("dt_ultimo_acesso")]
        public DateTime DataUltimoAcesso { get; set; }

        /// <summary>
        /// Número de tentativas de login inválidas (para bloqueio).
        /// </summary>
        [Display(Name = "Tentativas de login inválidas")]
        [Column("nr_tentativa_login_invalidas")]
        public int TentativasLoginInvalidas { get; set; }

        /// <summary>
        /// Indica se o usuário está bloqueado ou não (Enum SimNao).
        /// </summary>
        [Column("bl_bloqueado")]
        public bool Bloqueado { get; set; }

        /// <summary>
        /// Indica se o usuário deve alterar a senha (senha expirada ou lembrete de senha) - Enum SimNao.
        /// </summary>
        [Display(Name = "Alterar Senha?")]
        [Column("bl_alterar_senha")]
        public bool AlterarSenha { get; set; }

        /// <summary>
        /// Token SHA512 único para o usuário, usado como parâmetro para reset de senha.
        /// </summary>
        [Column("ds_token")]
        public string Token { get; set; }

        [Column("dt_validade_token")]
        public DateTime DataValidadeToken { get; set; }

        /// <summary>
        /// CPF.
        /// </summary>
        [Display(Name = "CPF")]
        [Column("ds_cpf")]
        public string CPF { get; set; }

        
        public int Perfil { get; set; }

        public List<PerfilUsuario> ListaPerfis { get; set; }

        [Column("Perfis")]
        public string Perfis { get; set; }

        public TipoAutenticacao TipoAutenticacao { get; set; }

        public string GetLogName()
        {
            return "TB_USUARIO";
        }

}
